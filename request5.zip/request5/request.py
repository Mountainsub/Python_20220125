#import sys
#import re
from rakuten_rss import rss, rss2 
from lib.ddeclient import DDEClient
import pandas as pd
import numpy as np
import time 
import sys
import os





time.sleep(1)

#dde_ware = []

def Main():
    calc = 0
    k = 504
    #dde_ware, calc = rss("現在値",k)[0], rss("現在値",k)[1]
    #print(calc)
    return rss("現在値",k)
    
    
dde_ware = Main()[0]
indexes_weight = Main()[2]


def calculation(dde_ware, indexes_weight):
    while True:
        t1 = time.time()
        calc = rss2("現在値",0, dde_ware, indexes_weight)
        
        t2 = time.time()
        print("経過時間:" + str(t2-t1), calc)
    return 0

#calculation(dde_ware, indexes_weight)
